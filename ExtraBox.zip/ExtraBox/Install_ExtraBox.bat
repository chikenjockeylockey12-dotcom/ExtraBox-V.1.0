@echo off
setlocal EnableExtensions
title ExtraBox V1.0 Installer
color 0A

set "INSTALL_DIR=%~dp0"
set "SOURCE_EXE=%~dp0dist\ExtraBox_V.1.0.exe"
set "SOURCE_CERT=%~dp0ExtraBox_Developer.cer"
set "TARGET_EXE=%INSTALL_DIR%ExtraBox_V.1.0.exe"
set "TARGET_CERT=%INSTALL_DIR%ExtraBox_Developer.cer"
set "README=%INSTALL_DIR%README_FIRST.txt"
set "LICENSE=%INSTALL_DIR%EXTRABOX_LICENSE.txt"
set "CERT_SCRIPT=%INSTALL_DIR%Open_ExtraBox_Certificate.ps1"

cls
echo ============================================================
echo                   EXTRABOX V1.0 SETUP
echo ============================================================
echo.
echo Installation folder:
echo "%INSTALL_DIR%"
echo.
echo SECURITY NOTICE
echo ExtraBox uses a self-signed code-signing certificate.
echo This installer will NOT automatically trust or install it.
echo Please read the license and security notice before continuing.
echo.
echo QEMU must be installed separately.
echo Official QEMU website: https://www.qemu.org/
echo.
pause

REM ------------------------------------------------------------
REM STEP 1 - CHECK REQUIRED FILES
REM ------------------------------------------------------------
cls
echo ============================================================
echo                   EXTRABOX V1.0 SETUP
echo ============================================================
echo.
echo [1/4] Checking required files...

if not exist "%SOURCE_EXE%" (
    echo.
    echo ERROR: ExtraBox_V.1.0.exe was not found:
    echo "%SOURCE_EXE%"
    echo.
    echo Make sure dist\ExtraBox_V.1.0.exe exists beside this installer.
    pause
    exit /b 1
)

if not exist "%SOURCE_CERT%" (
    echo.
    echo ERROR: ExtraBox_Developer.cer was not found:
    echo "%SOURCE_CERT%"
    echo.
    echo Place ExtraBox_Developer.cer beside Install_ExtraBox.bat.
    pause
    exit /b 1
)

echo Required files found.

REM ------------------------------------------------------------
REM STEP 2 - COPY EXE
REM ------------------------------------------------------------
echo.
echo [2/4] Copying ExtraBox executable...

copy /Y "%SOURCE_EXE%" "%TARGET_EXE%" >nul
if errorlevel 1 (
    echo ERROR: Could not copy the executable.
    pause
    exit /b 1
)
echo Executable copied.

REM ------------------------------------------------------------
REM STEP 3 - COPY CERTIFICATE AND CREATE LICENSE / README
REM ------------------------------------------------------------
echo.
echo [3/4] Copying certificate and creating notices...

copy /Y "%SOURCE_CERT%" "%TARGET_CERT%" >nul
if errorlevel 1 (
    echo ERROR: Could not copy the certificate.
    pause
    exit /b 1
)

(
    echo EXTRABOX V1.0 - SECURITY AND SOFTWARE LICENSE NOTICE
    echo.
    echo Please read this notice before using ExtraBox.
    echo.
    echo ExtraBox uses a self-signed code-signing certificate named
    echo "ExtraBox Developer". A self-signed certificate is not
    echo independently verified by a public Certificate Authority.
    echo.
    echo A valid signature means the signature verifies against the
    echo signing certificate and the signed file has not changed
    echo since signing. It does not guarantee that the program is
    echo harmless or prove the developer's real-world identity.
    echo.
    echo You are responsible for deciding whether to run the software
    echo and whether to trust its certificate. Installing a certificate
    echo into a trusted Windows store changes Windows trust settings
    echo and is optional.
    echo.
    echo Do not install or trust certificates unless you have verified
    echo their origin and understand the consequences. No guarantee of
    echo absolute safety is made.
    echo.
    echo QEMU is separate software. Official website:
    echo https://www.qemu.org/
) > "%LICENSE%"

if not exist "%LICENSE%" (
    echo ERROR: Could not create EXTRABOX_LICENSE.txt.
    pause
    exit /b 1
)

(
    echo EXTRABOX V1.0 - CERTIFICATE INSPECTION
    echo.
    echo To inspect the EXE signature:
    echo 1. Right-click ExtraBox_V.1.0.exe and choose Properties.
    echo 2. Open Digital Signatures, if that tab is available.
    echo 3. Inspect the signer and certificate details.
    echo.
    echo The included ExtraBox_Developer.cer is self-signed.
    echo Opening the CER file lets you inspect its certificate details.
    echo It does NOT automatically install the certificate or make it
    echo publicly trusted.
    echo.
    echo Only install or trust it if you independently verified its
    echo origin and choose to trust it. Installation changes Windows
    echo trust settings and is optional.
    echo.
    echo Read EXTRABOX_LICENSE.txt before using ExtraBox.
) > "%README%"

if not exist "%README%" (
    echo ERROR: Could not create README_FIRST.txt.
    pause
    exit /b 1
)

REM Create a PowerShell helper that displays a warning and opens the CER.
REM It does not import the certificate or change Windows trust settings.
echo Add-Type -AssemblyName PresentationFramework> "%CERT_SCRIPT%"
echo $certificatePath = Join-Path -Path $PSScriptRoot -ChildPath 'ExtraBox_Developer.cer'>> "%CERT_SCRIPT%"
echo [System.Windows.MessageBox]::Show('ExtraBox uses a self-signed certificate. Inspect its details before deciding whether to trust it. Opening this file does not install or trust the certificate.','ExtraBox Certificate Notice',[System.Windows.MessageBoxButton]::OK,[System.Windows.MessageBoxImage]::Warning) ^| Out-Null>> "%CERT_SCRIPT%"
echo Start-Process -FilePath $certificatePath>> "%CERT_SCRIPT%"

if not exist "%CERT_SCRIPT%" (
    echo ERROR: Could not create Open_ExtraBox_Certificate.ps1.
    pause
    exit /b 1
)

echo Certificate copied.
echo EXTRABOX_LICENSE.txt created.
echo README_FIRST.txt created.
echo Open_ExtraBox_Certificate.ps1 created.

REM ------------------------------------------------------------
REM STEP 4 - CREATE COMPONENT FILES
REM ------------------------------------------------------------
echo.
echo [4/4] Creating ExtraBox component files...

for /L %%i in (1,1,20) do (
    > "%INSTALL_DIR%ExtraBox_Component_%%i.dat" echo ExtraBox V1.0 Installation Component %%i
    if not exist "%INSTALL_DIR%ExtraBox_Component_%%i.dat" (
        echo ERROR: Could not create component %%i.
        pause
        exit /b 1
    )
    echo [%%i/20] Created ExtraBox_Component_%%i.dat
)

REM ------------------------------------------------------------
REM COMPLETION
REM ------------------------------------------------------------
echo.
echo ============================================================
echo                   INSTALLATION COMPLETE
echo ============================================================
echo.
echo Installed files:
echo   ExtraBox_V.1.0.exe
echo   ExtraBox_Developer.cer
echo   EXTRABOX_LICENSE.txt
echo   README_FIRST.txt
echo   Open_ExtraBox_Certificate.ps1
echo   ExtraBox_Component_1.dat through Component_20.dat
echo.
echo A certificate inspection notice will appear next.
echo The certificate will NOT be installed automatically.
echo.
pause

REM Run the generated PowerShell helper to warn the user and open the CER.
REM This intentionally does not import or trust the certificate.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%CERT_SCRIPT%"

echo.
echo Read EXTRABOX_LICENSE.txt before using ExtraBox.
echo.
choice /C YN /N /M "Launch ExtraBox now? [Y/N] "
if errorlevel 2 goto FINISH

if exist "%TARGET_EXE%" (
    start "" "%TARGET_EXE%"
) else (
    echo ERROR: ExtraBox executable could not be found.
)

:FINISH
echo.
echo Thank you for using ExtraBox V1.0.
pause
exit /b 0
